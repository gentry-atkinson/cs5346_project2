#include <iostream>
#include <cstdio>
#include <ctime>

#include "Tree.h"

using namespace std;

int main()
{
  //  int nodes_Expanded;
    Tree * tree1, * tree2;
    char lastPlayer, currentPlayer;
    int lastMove, aScore, bScore, depth, turn;

    //Case 1: Vishal vs. Gentry with MinMaxAB at depth 3
    cout << "***************************" << endl;
    cout << "Vishal vs. Gentry with MinMaxAB at depth 3" << endl;
    depth = 3;
    tree1 = new Tree(Tree::MINMAXAB, Tree::GENTRY, depth, 'A');
    tree2 = new Tree(Tree::MINMAXAB, Tree::VISHAL, depth, 'B');
    currentPlayer = 'A';
    lastPlayer = Tree::FIRST_MOVE;
    lastMove = 0;
    turn = 0;
    aScore = 0;
    bScore = 0;

    int start=clock();
    while(! tree1->getFinished() && ! tree2->getFinished()){
        tree1->play(currentPlayer, lastPlayer, lastMove);
        tree1->draw();
        cout<<endl;
        tree2->play(currentPlayer, lastPlayer, lastMove);
        tree2->draw();
        cout<<endl;
        turn++;
        //tree1->draw();
        //tree2->draw();
        //getchar();
    }

    int stop = clock();
    int execution_time= stop-start;
    cout<<"EXECUTION TIME : "<<(execution_time)/double(CLOCKS_PER_SEC)*1000<<" Seconds"<<endl;

   // cout<<"Number of nodes expanded "<< nodes_Expanded <<endl;

    aScore = tree2->getAScore();
    bScore = tree2->getBScore();

    cout << turn << " turns played" << endl;

    if (aScore > bScore){
        cout << "Gentry wins " << aScore << " to " << bScore << endl;
    }
    else if (bScore > aScore){
        cout << "Vishal wins " << bScore << " to " << aScore << endl;
    }
    else {
        cout << "Tie game." << endl;
    }

    delete tree1;
    delete tree2;
    getchar();
    //Case 2: Vishal vs. Gentry with AlphaBeta at depth 3

    cout << "***************************" << endl;
    cout << "Vishal vs. Gentry with AlphaBeta at depth 3" << endl;
    depth = 3;
    tree1 = new Tree(Tree::ALPHABETA, Tree::GENTRY, depth, 'A');
    tree2 = new Tree(Tree::ALPHABETA, Tree::VISHAL, depth, 'B');
    currentPlayer = 'A';
    lastPlayer = Tree::FIRST_MOVE;
    lastMove = 0;
    turn = 0;
    aScore = 0;
    bScore = 0;

    int start_2=clock();
    while(! tree1->getFinished() && ! tree2->getFinished()){
        tree1->play(currentPlayer, lastPlayer, lastMove);
        tree1->draw();
        cout<<endl;
        tree2->play(currentPlayer, lastPlayer, lastMove);
        tree2->draw();
        cout<<endl;
        turn++;
        //tree1->draw();
        //tree2->draw();
        //getchar();
    }

    int stop_2 = clock();
    execution_time= stop_2-start_2;
    cout<<"EXECUTION TIME : "<<(execution_time)/double(CLOCKS_PER_SEC)*1000<<" Seconds"<<endl;

    aScore = tree2->getAScore();
    bScore = tree2->getBScore();

    cout << turn << " turns played" << endl;

    if (aScore > bScore){
        cout << "Gentry wins " << aScore << " to " << bScore << endl;
    }
    else if (bScore > aScore){
        cout << "Vishal wins " << bScore << " to " << aScore << endl;
    }
    else {
        cout << "Tie game." << endl;
    }

    delete tree1;
    delete tree2;
    getchar();

    //Case 3: MinMax vs. AlphaBeta with Vishal at depth 3
    cout << "***************************" << endl;
    cout << "MinMax vs. AlphaBeta with Vishal at depth 3" << endl;
    depth = 3;
    tree1 = new Tree(Tree::MINMAXAB, Tree::VISHAL, depth, 'A');
    tree2 = new Tree(Tree::ALPHABETA, Tree::VISHAL, depth, 'B');
    currentPlayer = 'A';
    lastPlayer = Tree::FIRST_MOVE;
    lastMove = 0;
    turn = 0;
    aScore = 0;
    bScore = 0;

    int start_3=clock();
    while(! tree1->getFinished() && ! tree2->getFinished()){
        tree1->play(currentPlayer, lastPlayer, lastMove);
        tree1->draw();
        cout<<endl;
        tree2->play(currentPlayer, lastPlayer, lastMove);
        tree2->draw();
        cout<<endl;
        turn++;
        //tree1->draw();
        //tree2->draw();
        //getchar();
    }

    int stop_3 = clock();
    execution_time= stop_3-start_3;
    cout<<"EXECUTION TIME : "<<(execution_time)/double(CLOCKS_PER_SEC)*1000<<" Seconds"<<endl;

    aScore = tree2->getAScore();
    bScore = tree2->getBScore();

    cout << turn << " turns played" << endl;

    if (aScore > bScore){
        cout << "MinMaxAB wins " << aScore << " to " << bScore << endl;
    }
    else if (bScore > aScore){
        cout << "AlphaBeta wins " << bScore << " to " << aScore << endl;
    }
    else {
        cout << "Tie game." << endl;
    }

    delete tree1;
    delete tree2;
    getchar();

    //Case 4: MinMax vs. AlphaBeta with Gentry at depth 3
    cout << "***************************" << endl;
    cout << "MinMax vs. AlphaBeta with Gentry at depth 3" << endl;
    depth = 3;
    tree1 = new Tree(Tree::MINMAXAB, Tree::GENTRY, depth, 'A');
    tree2 = new Tree(Tree::ALPHABETA, Tree::GENTRY, depth, 'B');
    currentPlayer = 'A';
    lastPlayer = Tree::FIRST_MOVE;
    lastMove = 0;
    turn = 0;
    aScore = 0;
    bScore = 0;

    int start_4=clock();
    while(! tree1->getFinished() && ! tree2->getFinished()){
        tree1->play(currentPlayer, lastPlayer, lastMove);
        tree1->draw();
        cout<<endl;
        tree2->play(currentPlayer, lastPlayer, lastMove);
        tree2->draw();
        cout<<endl;
        turn++;
        //tree1->draw();
        //tree2->draw();
        //getchar();
    }

    int stop_4 = clock();
    execution_time= stop_4-start_4;
    cout<<"EXECUTION TIME : "<<(execution_time)/double(CLOCKS_PER_SEC)*1000<<" Seconds"<<endl;

    aScore = tree2->getAScore();
    bScore = tree2->getBScore();

    cout << turn << " turns played" << endl;

    if (aScore > bScore){
        cout << "MinMaxAB wins " << aScore << " to " << bScore << endl;
    }
    else if (bScore > aScore){
        cout << "AlphaBeta wins " << bScore << " to " << aScore << endl;
    }
    else {
        cout << "Tie game." << endl;
    }

    delete tree1;
    delete tree2;
    getchar();

    //Case 5: Vishal vs. Gentry with MinMaxAB at depth 5
    cout << "***************************" << endl;
    cout << "Vishal vs. Gentry with MinMaxAB at depth 5" << endl;
    depth = 5;
    tree1 = new Tree(Tree::MINMAXAB, Tree::GENTRY, depth, 'A');
    tree2 = new Tree(Tree::MINMAXAB, Tree::VISHAL, depth, 'B');
    currentPlayer = 'A';
    lastPlayer = Tree::FIRST_MOVE;
    lastMove = 0;
    turn = 0;
    aScore = 0;
    bScore = 0;

        int start_5=clock();
    while(! tree1->getFinished() && ! tree2->getFinished()){
        tree1->play(currentPlayer, lastPlayer, lastMove);
        tree1->draw();
        cout<<endl;
        tree2->play(currentPlayer, lastPlayer, lastMove);
        tree2->draw();
        cout<<endl;
        turn++;
        //tree1->draw();
        //tree2->draw();
        //getchar();
    }

    int stop_5 = clock();
    execution_time= stop_5-start_5;
    cout<<"EXECUTION TIME : "<<(execution_time)/double(CLOCKS_PER_SEC)*1000<<" Seconds"<<endl;

    aScore = tree2->getAScore();
    bScore = tree2->getBScore();

    cout << turn << " turns played" << endl;

    if (aScore > bScore){
        cout << "Gentry wins " << aScore << " to " << bScore << endl;
    }
    else if (bScore > aScore){
        cout << "Vishal wins " << bScore << " to " << aScore << endl;
    }
    else {
        cout << "Tie game." << endl;
    }

    delete tree1;
    delete tree2;
    getchar();

    //Case 6: Vishal vs. Gentry with AlphaBeta at depth 5
    cout << "***************************" << endl;
    cout << "Vishal vs. Gentry with AlphaBeta at depth 5" << endl;
    depth = 5;
    tree1 = new Tree(Tree::ALPHABETA, Tree::GENTRY, depth, 'A');
    tree2 = new Tree(Tree::ALPHABETA, Tree::VISHAL, depth, 'B');
    currentPlayer = 'A';
    lastPlayer = Tree::FIRST_MOVE;
    lastMove = 0;
    turn = 0;
    aScore = 0;
    bScore = 0;

    int start_6=clock();
    while(! tree1->getFinished() && ! tree2->getFinished()){
        tree1->play(currentPlayer, lastPlayer, lastMove);
        tree1->draw();
        cout<<endl;
        tree2->play(currentPlayer, lastPlayer, lastMove);
        tree2->draw();
        cout<<endl;
        turn++;
        //tree1->draw();
        //tree2->draw();
        //getchar();
    }

    int stop_6 = clock();
    execution_time= stop_6-start_6;
    cout<<"EXECUTION TIME : "<<(execution_time)/double(CLOCKS_PER_SEC)*1000<<" Seconds"<<endl;
    aScore = tree2->getAScore();
    bScore = tree2->getBScore();

    cout << turn << " turns played" << endl;

    if (aScore > bScore){
        cout << "Gentry wins " << aScore << " to " << bScore << endl;
    }
    else if (bScore > aScore){
        cout << "Vishal wins " << bScore << " to " << aScore << endl;
    }
    else {
        cout << "Tie game." << endl;
    }

    delete tree1;
    delete tree2;
    getchar();

    //Case 7: MinMax vs. AlphaBeta with Vishal at depth 5
    cout << "***************************" << endl;
    cout << "MinMax vs. AlphaBeta with Vishal at depth 5" << endl;
    depth = 5;
    tree1 = new Tree(Tree::MINMAXAB, Tree::VISHAL, depth, 'A');
    tree2 = new Tree(Tree::ALPHABETA, Tree::VISHAL, depth, 'B');
    currentPlayer = 'A';
    lastPlayer = Tree::FIRST_MOVE;
    lastMove = 0;
    turn = 0;
    aScore = 0;
    bScore = 0;

       int start_7=clock();
    while(! tree1->getFinished() && ! tree2->getFinished()){
        tree1->play(currentPlayer, lastPlayer, lastMove);
        tree1->draw();
        cout<<endl;
        tree2->play(currentPlayer, lastPlayer, lastMove);
        tree2->draw();
        cout<<endl;
        turn++;
        //tree1->draw();
        //tree2->draw();
        //getchar();
    }

    int stop_7 = clock();
    execution_time= stop_7-start_7;
    cout<<"EXECUTION TIME : "<<(execution_time)/double(CLOCKS_PER_SEC)*1000<<" Seconds"<<endl;

    aScore = tree2->getAScore();
    bScore = tree2->getBScore();

    cout << turn << " turns played" << endl;

    if (aScore > bScore){
        cout << "MinMaxAB wins " << aScore << " to " << bScore << endl;
    }
    else if (bScore > aScore){
        cout << "AlphaBeta wins " << bScore << " to " << aScore << endl;
    }
    else {
        cout << "Tie game." << endl;
    }

    delete tree1;
    delete tree2;
    getchar();

    //Case 8: MinMax vs. AlphaBeta with Gentry at depth 5
    cout << "***************************" << endl;
    cout << "MinMax vs. AlphaBeta with Gentry at depth 5" << endl;
    depth = 5;
    tree1 = new Tree(Tree::MINMAXAB, Tree::GENTRY, depth, 'A');
    tree2 = new Tree(Tree::ALPHABETA, Tree::GENTRY, depth, 'B');
    currentPlayer = 'A';
    lastPlayer = Tree::FIRST_MOVE;
    lastMove = 0;
    turn = 0;
    aScore = 0;
    bScore = 0;

       int start_8=clock();
    while(! tree1->getFinished() && ! tree2->getFinished()){
        tree1->play(currentPlayer, lastPlayer, lastMove);
        tree1->draw();
        cout<<endl;
        tree2->play(currentPlayer, lastPlayer, lastMove);
        tree2->draw();
        cout<<endl;
        turn++;
        //tree1->draw();
        //tree2->draw();
        //getchar();
    }

    int stop_8 = clock();
    execution_time= stop_8-start_8;
    cout<<"EXECUTION TIME : "<<(execution_time)/double(CLOCKS_PER_SEC)*1000<<" Seconds"<<endl;

    aScore = tree2->getAScore();
    bScore = tree2->getBScore();

    cout << turn << " turns played" << endl;

    if (aScore > bScore){
        cout << "MinMaxAB wins " << aScore << " to " << bScore << endl;
    }
    else if (bScore > aScore){
        cout << "AlphaBeta wins " << bScore << " to " << aScore << endl;
    }
    else {
        cout << "Tie game." << endl;
    }

    delete tree1;
    delete tree2;
    getchar();

    //Case 9: Vishal vs. Gentry with MinMaxAB at depth 7
    cout << "***************************" << endl;
    cout << "Vishal vs. Gentry with MinMaxAB at depth 7" << endl;
    depth = 7;
    tree1 = new Tree(Tree::MINMAXAB, Tree::GENTRY, depth, 'A');
    tree2 = new Tree(Tree::MINMAXAB, Tree::VISHAL, depth, 'B');
    //cout << "Total tree size is: " << tree1->getTotalBoards() << endl;
    currentPlayer = 'A';
    lastPlayer = Tree::FIRST_MOVE;
    lastMove = 0;
    turn = 0;
    aScore = 0;
    bScore = 0;

       int start_9=clock();
    while(! tree1->getFinished() && ! tree2->getFinished()){
        tree1->play(currentPlayer, lastPlayer, lastMove);
        tree1->draw();
        cout<<endl;
        tree2->play(currentPlayer, lastPlayer, lastMove);
        tree2->draw();
        cout<<endl;
        turn++;
        //tree1->draw();
        //tree2->draw();
        //getchar();
    }

    int stop_9 = clock();
    execution_time= stop_9-start_9;
    cout<<"EXECUTION TIME : "<<(execution_time)/double(CLOCKS_PER_SEC)*1000<<" Seconds"<<endl;
    aScore = tree2->getAScore();
    bScore = tree2->getBScore();

    cout << turn << " turns played" << endl;

    if (aScore > bScore){
        cout << "Gentry wins " << aScore << " to " << bScore << endl;
    }
    else if (bScore > aScore){
        cout << "Vishal wins " << bScore << " to " << aScore << endl;
    }
    else {
        cout << "Tie game." << endl;
    }

    delete tree1;
    delete tree2;
    getchar();

    //Case 10: Vishal vs. Gentry with AlphaBeta at depth 7
    cout << "***************************" << endl;
    cout << "Vishal vs. Gentry with AlphaBeta at depth 7" << endl;
    depth = 7;
    tree1 = new Tree(Tree::ALPHABETA, Tree::GENTRY, depth, 'A');
    tree2 = new Tree(Tree::ALPHABETA, Tree::VISHAL, depth, 'B');
    currentPlayer = 'A';
    lastPlayer = Tree::FIRST_MOVE;
    lastMove = 0;
    turn = 0;
    aScore = 0;
    bScore = 0;

    int start_10=clock();
    while(! tree1->getFinished() && ! tree2->getFinished()){
        tree1->play(currentPlayer, lastPlayer, lastMove);
        tree1->draw();
        cout<<endl;
        tree2->play(currentPlayer, lastPlayer, lastMove);
        tree2->draw();
        cout<<endl;
        turn++;
        //tree1->draw();
        //tree2->draw();
        //getchar();
    }

    int stop_10 = clock();
    execution_time= stop_10-start_10;
    cout<<"EXECUTION TIME : "<<(execution_time)/double(CLOCKS_PER_SEC)*1000<<" Seconds"<<endl;

    aScore = tree2->getAScore();
    bScore = tree2->getBScore();

    cout << turn << " turns played" << endl;

    if (aScore > bScore){
        cout << "Gentry wins " << aScore << " to " << bScore << endl;
    }
    else if (bScore > aScore){
        cout << "Vishal wins " << bScore << " to " << aScore << endl;
    }
    else {
        cout << "Tie game." << endl;
    }

    delete tree1;
    delete tree2;
    getchar();

    //Case 11: MinMax vs. AlphaBeta with Vishal at depth 7
    cout << "***************************" << endl;
    cout << "MinMax vs. AlphaBeta with Vishal at depth 7" << endl;
    depth = 7;
    tree1 = new Tree(Tree::MINMAXAB, Tree::VISHAL, depth, 'A');
    tree2 = new Tree(Tree::ALPHABETA, Tree::VISHAL, depth, 'B');
    currentPlayer = 'A';
    lastPlayer = Tree::FIRST_MOVE;
    lastMove = 0;
    turn = 0;
    aScore = 0;
    bScore = 0;

    int start_11=clock();
    while(! tree1->getFinished() && ! tree2->getFinished()){
        tree1->play(currentPlayer, lastPlayer, lastMove);
        tree1->draw();
        cout<<endl;
        tree2->play(currentPlayer, lastPlayer, lastMove);
        tree2->draw();
        cout<<endl;
        turn++;
        //tree1->draw();
        //tree2->draw();
        //getchar();
    }

    int stop_11 = clock();
    execution_time= stop_11-start_11;
    cout<<"EXECUTION TIME : "<<(execution_time)/double(CLOCKS_PER_SEC)*1000<<" Seconds"<<endl;

    aScore = tree2->getAScore();
    bScore = tree2->getBScore();

    cout << turn << " turns played" << endl;

    if (aScore > bScore){
        cout << "MinMaxAB wins " << aScore << " to " << bScore << endl;
    }
    else if (bScore > aScore){
        cout << "AlphaBeta wins " << bScore << " to " << aScore << endl;
    }
    else {
        cout << "Tie game." << endl;
    }

    delete tree1;
    delete tree2;
    getchar();
    //Case 12: MinMax vs. AlphaBeta with Gentry at depth 7
    cout << "***************************" << endl;
    cout << "MinMax vs. AlphaBeta with Gentry at depth 7" << endl;
    depth = 7;
    tree1 = new Tree(Tree::MINMAXAB, Tree::GENTRY, depth, 'A');
    tree2 = new Tree(Tree::ALPHABETA, Tree::GENTRY, depth, 'B');
    currentPlayer = 'A';
    lastPlayer = Tree::FIRST_MOVE;
    lastMove = 0;
    turn = 0;
    aScore = 0;
    bScore = 0;

    int start_12=clock();
    while(! tree1->getFinished() && ! tree2->getFinished()){
        tree1->play(currentPlayer, lastPlayer, lastMove);
        tree1->draw();
        cout<<endl;
        tree2->play(currentPlayer, lastPlayer, lastMove);
        tree2->draw();
        cout<<endl;
        turn++;
        //tree1->draw();
        //tree2->draw();
        //getchar();
    }

    int stop_12 = clock();
    execution_time= stop_12-start_12;
    cout<<"EXECUTION TIME : "<<(execution_time)/double(CLOCKS_PER_SEC)*1000<<" Seconds"<<endl;

    aScore = tree2->getAScore();
    bScore = tree2->getBScore();

    cout << turn << " turns played" << endl;

    if (aScore > bScore){
        cout << "MinMaxAB wins " << aScore << " to " << bScore << endl;
    }
    else if (bScore > aScore){
        cout << "AlphaBeta wins " << bScore << " to " << aScore << endl;
    }
    else {
        cout << "Tie game." << endl;
    }

    delete tree1;
    delete tree2;

    return 0;
}
